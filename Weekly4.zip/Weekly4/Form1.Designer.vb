﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class airbnb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblOrlandoBnB = New System.Windows.Forms.Label()
        Me.lblBaseCost = New System.Windows.Forms.Label()
        Me.lblNightNumber = New System.Windows.Forms.Label()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        Me.btnCost = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.picBnB = New System.Windows.Forms.PictureBox()
        Me.txtNights = New System.Windows.Forms.TextBox()
        Me.lblCostofStay = New System.Windows.Forms.Label()
        CType(Me.picBnB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblOrlandoBnB
        '
        Me.lblOrlandoBnB.Font = New System.Drawing.Font("Cooper Black", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrlandoBnB.Location = New System.Drawing.Point(272, 32)
        Me.lblOrlandoBnB.Name = "lblOrlandoBnB"
        Me.lblOrlandoBnB.Size = New System.Drawing.Size(350, 33)
        Me.lblOrlandoBnB.TabIndex = 0
        Me.lblOrlandoBnB.Text = "Orlando AirBnB"
        Me.lblOrlandoBnB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblBaseCost
        '
        Me.lblBaseCost.AutoSize = True
        Me.lblBaseCost.Font = New System.Drawing.Font("Cooper Black", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBaseCost.Location = New System.Drawing.Point(392, 65)
        Me.lblBaseCost.Name = "lblBaseCost"
        Me.lblBaseCost.Size = New System.Drawing.Size(131, 13)
        Me.lblBaseCost.TabIndex = 1
        Me.lblBaseCost.Text = "Only $79.99 per night"
        '
        'lblNightNumber
        '
        Me.lblNightNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNightNumber.Location = New System.Drawing.Point(370, 125)
        Me.lblNightNumber.Name = "lblNightNumber"
        Me.lblNightNumber.Size = New System.Drawing.Size(122, 30)
        Me.lblNightNumber.TabIndex = 2
        Me.lblNightNumber.Text = "Number of Nights:"
        Me.lblNightNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalCost
        '
        Me.lblTotalCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCost.Location = New System.Drawing.Point(514, 189)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(100, 23)
        Me.lblTotalCost.TabIndex = 3
        '
        'btnCost
        '
        Me.btnCost.Location = New System.Drawing.Point(307, 287)
        Me.btnCost.Name = "btnCost"
        Me.btnCost.Size = New System.Drawing.Size(75, 23)
        Me.btnCost.TabIndex = 4
        Me.btnCost.Text = "Display Cost"
        Me.btnCost.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(417, 287)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(517, 287)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'picBnB
        '
        Me.picBnB.Image = Global.Weekly4.My.Resources.Resources.airbnb
        Me.picBnB.Location = New System.Drawing.Point(12, 32)
        Me.picBnB.Name = "picBnB"
        Me.picBnB.Size = New System.Drawing.Size(270, 367)
        Me.picBnB.TabIndex = 7
        Me.picBnB.TabStop = False
        '
        'txtNights
        '
        Me.txtNights.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNights.Location = New System.Drawing.Point(517, 129)
        Me.txtNights.Name = "txtNights"
        Me.txtNights.Size = New System.Drawing.Size(42, 20)
        Me.txtNights.TabIndex = 8
        '
        'lblCostofStay
        '
        Me.lblCostofStay.AutoSize = True
        Me.lblCostofStay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCostofStay.Location = New System.Drawing.Point(392, 189)
        Me.lblCostofStay.Name = "lblCostofStay"
        Me.lblCostofStay.Size = New System.Drawing.Size(80, 13)
        Me.lblCostofStay.TabIndex = 9
        Me.lblCostofStay.Text = "Cost of Stay:"
        '
        'airbnb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkKhaki
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblCostofStay)
        Me.Controls.Add(Me.txtNights)
        Me.Controls.Add(Me.picBnB)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCost)
        Me.Controls.Add(Me.lblTotalCost)
        Me.Controls.Add(Me.lblNightNumber)
        Me.Controls.Add(Me.lblBaseCost)
        Me.Controls.Add(Me.lblOrlandoBnB)
        Me.Name = "airbnb"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AirBnB Reservations"
        CType(Me.picBnB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblOrlandoBnB As Label
    Friend WithEvents lblBaseCost As Label
    Friend WithEvents lblNightNumber As Label
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents btnCost As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents picBnB As PictureBox
    Friend WithEvents txtNights As TextBox
    Friend WithEvents lblCostofStay As Label
End Class
