﻿Public Class airbnb


    Private Sub form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtNights.Clear()
        lblTotalCost.Text = ""
        txtNights.Focus()
    End Sub


    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtNights.Clear()
    End Sub

    Private Sub btnDisplayCost_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCost.Click
        Dim strEnterNumberOfNights As String
        Dim intEnterNumberOfNights As Integer
        Dim decTotalCostOfStay As Decimal
        Const cdecCostPerNight As Decimal = 79D
        strEnterNumberOfNights = txtNights.Text
        intEnterNumberOfNights = Convert.ToInt32(strEnterNumberOfNights)
        decTotalCostOfStay = intEnterNumberOfNights * cdecCostPerNight
        lblTotalCost.Text = decTotalCostOfStay.ToString("C")
    End Sub
    Private Sub buttonExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
